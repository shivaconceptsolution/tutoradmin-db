from django.shortcuts import render,redirect;
from tutoradmin.models import Faculty
from django.http import HttpResponse
def index(request):
	if request.method=="POST":
		chkemail= Faculty.objects.filter(email=request.POST["txtemail"])
		if chkemail.count()>0:
			return HttpResponse("Emailid already exist")
		else:
			obj = Faculty(email=request.POST["txtemail"],password=request.POST["txtpass"],mobile=request.POST["txtmobile"],fname=request.POST["txtfname"],exp=request.POST["txtexp"])
			obj.save()
			return render(request,"faculty/home.html",{'res':'Registration Successfully'})
	return render(request,"faculty/home.html")


def login(request):
	if request.method=="POST":
		obj = Faculty.objects.filter(email=request.POST["txtemail"],password=request.POST["txtpass"])
		if obj.count()>0:
			request.session["fid"] = request.POST["txtemail"]
			return redirect('facultydash')
		else:
		   s="Invalid userid and password"
		   return render(request,"faculty/login.html",{"res":s})

	return render(request,"faculty/login.html")

def about(request):
	return render(request,"faculty/about.html")

def facultydash(request):
	data = Faculty.objects.filter(email=request.session["fid"])
	return render(request,"faculty/facultydash.html",{"res":data})

def logout(request):
    del request.session["fid"]
    return redirect('login')	