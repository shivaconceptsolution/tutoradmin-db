from django.shortcuts import render;
from tutoradmin.models import Faculty
def index(request):
	if request.method=="POST":
		obj = Faculty(email=request.POST["txtemail"],password=request.POST["txtpass"],mobile=request.POST["txtmobile"],fname=request.POST["txtfname"],exp=request.POST["txtexp"])
		obj.save()
		return render(request,"tutorcabin/home.html",{'res':'Registration Successfully'})
	return render(request,"tutorcabin/home.html")
def about(request):
	return render(request,"tutorcabin/about.html")