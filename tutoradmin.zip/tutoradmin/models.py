from django.db import models
class Faculty(models.Model):
	email = models.CharField(max_length=50)
	password = models.CharField(max_length=10)
	mobile = models.CharField(max_length=10)
	fname = models.CharField(max_length=10)
	exp = models.CharField(max_length=50)
	

class Course(models.Model):
	cname= models.CharField(max_length=50)
	duration= models.CharField(max_length=10)


