from django.contrib import admin
from .models import Alogin
admin.site.register(Alogin)
