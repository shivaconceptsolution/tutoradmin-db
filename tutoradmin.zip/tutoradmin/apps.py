from django.apps import AppConfig


class TutoradminConfig(AppConfig):
    name = 'tutoradmin'
